<section>
    <nav class="navbar navbar-expand-md navbar-light bg-white fixed-top d-flex shadow-sm">
        <div class="container">
            <a class="navbar-brand me-auto" href="<?php echo e(url('/')); ?>">
               <img src="<?php echo e(asset('templete/assets/img/logo-konsel.png')); ?>" alt="">
            </a>
            
                
            
            <button class="navbar-toggler p-0" type="button" data-bs-toggle="collapse" data-bs-target="#primaryNavbarCollapse" aria-controls="primaryNavbarCollapse" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="hamburger hamburger--emphatic">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </span>
            </button>
            <div class="collapse navbar-collapse  " id="navbarSupportedContent">
                <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>


                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ms-auto">
                    <!-- Authentication Links -->
                            <li class="nav-item">
                                <a class="btn btn-outline-danger rounded-pill btn-sm border-2 d-block d-lg-inline-block ms-auto my-3 my-lg-0 mx-3 nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link btn btn-danger btn-hover btn rounded-pill btn-sm border-2 d-block d-lg-inline-block ms-auto my-3 my-lg-0 mx-3" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
                </ul>
                        <?php endif; ?>
                    <?php else: ?>
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav " style="margin-left: 17em">
                        <li class="nav-item" >
                            <a class="nav-link" href="<?php echo e(route('service')); ?>">Services</a>
                        </li>
                        <li class="nav-item" >
                            <a class="nav-link" href="">Contact</a>
                        </li>
                        <li class="nav-item" >
                            <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
                        </li>
                        <li class="nav-item" >
                            <a class="nav-link" href="">Help</a>
                        </li>
                    </ul>
                <?php endif; ?>
                <?php if(Auth::user()): ?>
                
                <div class="dropdown ms-auto">
                    <a class="nav-link dropdown-toggle" href="#" role="button" id="navbarDropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                        
                </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <script src="<?php echo e(asset('templete/js/user.js')); ?>"></script>
  </section>

              
                <!-- Authentication Links -->
                
                    
                        
                            
                        
                    

                    
                        
                            
                        
                    
                
                    

                        

                             

<?php /**PATH E:\Magang MSIB\Projek\konsel.id\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>