<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset('templete/css/styles.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('templete/css/user.min.css')); ?>" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet" >
        
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('templete/js/user.js')); ?>" ></script>
    </head>

    <div id="app">
        <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    </html><?php /**PATH E:\Magang MSIB\Projek\konsel.id\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>