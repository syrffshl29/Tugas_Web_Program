

<?php $__env->startSection('title'); ?>
    Landing
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <body>
        
        
        <section style="font-family: font-family :Poppins;">
          <div class="bg-image" >
           <div class="container">

            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
              <div class="carousel-inner ">
                <div class="carousel-item active">
                  <div class="row">
                    <div class="col-sm-2 col-lg-8">
                      <div style="margin-top: 15em">
                        <h1 class="fs-4 fs-md-4 lh-1 text-black" > <b style=" font-size: 48px"> Kerjakan tes sekarang dan dapatkan rekomendasi dari <span class="text-danger">Konsel</span> tentang kemampuanmu.</b> </h1>
                      </div>
                    </div>
                  </div> 
                </div>
                <div class="carousel-item">
                  <div class="row">
                    <div class="col-sm-2 col-lg-8">
                      <div  style="margin-top: 15em">
                        <h1 class="fs-4 fs-md-4 lh-1 text-black" > <b style=" font-size: 48px"> Dengan bantuan psikolog, menyiapkan pemuda pemudi indonesia dalam menentukan masa depan.</b> </h1>
                      </div>
                    </div>
                  </div> 
                </div>
                <div class="carousel-item">
                  <div class="row">
                    <div class="col-sm-2 col-lg-8">
                      <div  style="margin-top: 15em">
                        <h1 class="fs-4 fs-md-4 lh-1 text-black" > <b style=" font-size: 48px"> menjadi cerdas dan berkarakter adalah tujuan utama sebuah pendidikan.</b> </h1>
                      </div>
                    </div>
                  </div> 
                </div>
              </div>
              <div class="overflow-hidden" >
                <p class="d-block d-lg-inline-block ms-auto my-3 my-lg-0 py-3">
                  <a class="btn btn-danger btn-hover rounded-pill btn-lg border-5 d-block d-lg-inline-block ms-auto my-3 my-lg-0 mx-3" href="/quiz" target="_blank">Mulai</a>
              </p>
              </div>

               
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next" style="margin-top: 6em; margin-left:3em">
                <span class="carousel-control-next-icon next-icon" aria-hidden="true"></span>
                <span class="">Next</span>
              </button> 
              
            </div>

            
                      
                      
                        
                    
                  
                  
               
              
            </div>
           </div>
          </div>
        </section>

        <section style="padding-top: 7em; padding-bottom:7em">
            
                <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                    
                    <div class="container" >
                    <div class="carousel-inner">
                      <div class="carousel-item active" data-bs-interval="10000">
                        <div class="row" style="font-family: Poppins">
                            <div class="col-6">
                                <div style="margin-left:7em" >
                                    <img src="<?php echo e(asset('templete/assets/img/client1.png')); ?>" alt="">
                                    <div class="img-border"></div>
                                </div>
                            </div>
                            <div class="col-6 align-self-center ">
                                <h1><b>David Beckham</b></h1>
                                <p class="pt-2 ">As a sales gamification company, we were skeptical to work with a consultant to optimize our sales emails, but Elixir was highly recommended by many other Y-Combinator startups we knew. Elixir helped us run a ~6 week
                                    email campaign.</p>
                                    <h4>Chairman, Harmony Corporation.</h4>
                                    
                            </div> 
                        </div>
                        
                        
                      </div>
                      <div class="carousel-item" data-bs-interval="2000">
                        <div class="row">
                            <div class="col-6">
                                <div style="margin-left:7em" >
                                    <img src="<?php echo e(asset('templete/assets/img/client2.png')); ?>" alt="">
                                    <div class="img-border"></div>
                                </div>
                            </div>
                            <div class="col-6 align-self-center">
                                <h1><b>Maria Sharapova</b></h1>
                                <p class="pt-2">Writing case studies was a daunting task for us. We didn't know where to begin or what questions to ask, and clients never seemed to follow through when we asked. Elixir team did everything – with almost no time or
                                    effort for me!.</p>
                                    <h4>Managing Director, Themewagon Inc.</h4>
                            </div> 
                        </div>
                        
                      </div>
                      <div class="carousel-item">
                        <div class="row">
                            <div class="col-6">
                                <div style="margin-left:10em" >
                                    <img src="<?php echo e(asset('templete/assets/img/client3.png')); ?>" alt="">
                                    <div class="img-border"></div>
                                </div>
                            </div>
                            <div class="col-6 align-self-center ">
                                <h1><b>Michael Clarke</b></h1>
                                <p class="pt-2">Their work on our website and Internet marketing has made a significant different to our business. We’ve seen a 425% increase in quote requests from the website which has been pretty remarkable – but I’d always like
                                    to see more!.</p>
                                    <h4>CEO, A.E.T Institute.</h4>
                            </div> 
                        </div>
                        
                      </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
            </div>
        </section>
        
        
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Magang MSIB\Projek\konsel.id\resources\views/landing.blade.php ENDPATH**/ ?>