<section>
    
    <nav class="navbar navbar-light bg-white mx-auto">
        <div class="container">
          <a class="navbar-brand" style="margin: auto" href="#">
            <img src="<?php echo e(asset('templete/assets/img/logo-konsel.png')); ?>" >
          </a>
        </div>
      </nav>
</section><?php /**PATH E:\Magang MSIB\Projek\konsel.id\resources\views/layouts/partials/navbartest.blade.php ENDPATH**/ ?>