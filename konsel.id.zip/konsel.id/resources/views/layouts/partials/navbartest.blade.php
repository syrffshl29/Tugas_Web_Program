<section>
    {{-- <img src="{{ asset('templete/assets/img/logo-konsel.png') }}" alt=""> --}}
    <nav class="navbar navbar-light bg-white mx-auto">
        <div class="container">
          <a class="navbar-brand" style="margin: auto" href="#">
            <img src="{{ asset('templete/assets/img/logo-konsel.png') }}" >
          </a>
        </div>
      </nav>
</section>