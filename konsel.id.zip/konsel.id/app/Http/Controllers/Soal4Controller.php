<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Soal4Controller extends Controller
{
    public function index()
    {
        return view ('soal4');
    }
}
