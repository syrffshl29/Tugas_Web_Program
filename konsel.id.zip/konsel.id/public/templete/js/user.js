// $(document).ready(function (){
    // $(window).scroll(function (){
//         var scroll = $(window).scrollTop();
//         if (scroll > 1) {
//             $(".navbar").css("background", "f5f5f5");
//             // $("#navbar").removeClass("sticky-top").addClass("fixed-top"); 
//         } 
//     })
// })
// (function($){
// 	$(window).scroll(function(event) {
// 		if( $(this).scrollTop() == 0 ){
// 			$(".navbar").css('background-color', 'transparent');
// 		} else {
// 			$("navbar").css('background-color', 'white');
// 		}
// 	});
// })(jQuery);